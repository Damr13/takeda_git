<script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();
  } );
            $(function () {
                $('#startShift').datetimepicker({
                    format: 'HH:mm'
                });
            });
            $(function () {
                $('#endShift').datetimepicker({
                    format: 'HH:mm'
                });
            });            
</script>