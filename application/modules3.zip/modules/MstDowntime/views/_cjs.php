<script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();
  } );
</script>