<script type="text/javascript">
  $(document).ready( function () {
    // var table = $('#table_visitor').DataTable({
    //     responsive: true,
    //     select: true,
    //     'aoColumnDefs': [{
    //         'bSortable': false,
    //         'aTargets': ['nosort']
    //     }]
    // });
    // $('#table_visitor tbody').on( 'click', 'tr', function() {
    //     if ( $(this).hasClass('selected') ) {
    //         $(this).removeClass('selected');
    //     }
    //     else {
    //         table.$('tr.selected').removeClass('selected');
    //         $(this).addClass('selected');
    //     }
    // });
    // var table = $('#table_contractor').DataTable({
    //     responsive: true,
    //     select: true,
    //     'aoColumnDefs': [{
    //         'bSortable': false,
    //         'aTargets': ['nosort']
    //     }]
    // });
    // $('#table_contractor tbody').on( 'click', 'tr', function() {
    //     if ( $(this).hasClass('selected') ) {
    //         $(this).removeClass('selected');
    //     }
    //     else {
    //         table.$('tr.selected').removeClass('selected');
    //         $(this).addClass('selected');
    //     }
    // });
    // var table = $('#table_employee').DataTable({
    //     responsive: true,
    //     select: true,
    //     'aoColumnDefs': [{
    //         'bSortable': false,
    //         'aTargets': ['nosort']
    //     }]
    // });
    // $('#table_employee tbody').on( 'click', 'tr', function() {
    //     if ( $(this).hasClass('selected') ) {
    //         $(this).removeClass('selected');
    //     }
    //     else {
    //         table.$('tr.selected').removeClass('selected');
    //         $(this).addClass('selected');
    //     }
    // });
    // var table = $('#table_outsourcing').DataTable({
    //     responsive: true,
    //     select: true,
    //     'aoColumnDefs': [{
    //         'bSortable': false,
    //         'aTargets': ['nosort']
    //     }]
    // });
    // $('#table_outsourcing tbody').on( 'click', 'tr', function() {
    //     if ( $(this).hasClass('selected') ) {
    //         $(this).removeClass('selected');
    //     }
    //     else {
    //         table.$('tr.selected').removeClass('selected');
    //         $(this).addClass('selected');
    //     }
    // });
    

  } );
</script>