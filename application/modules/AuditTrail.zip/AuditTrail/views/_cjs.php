<script type="text/javascript">
  $(document).ready(function() {

  // $('#bulan').datepicker({
  //     minViewMode: 1,
  //     keyboardNavigation: false,
  //     forceParse: false,
  //     autoclose: true,
  //     todayHighlight: true,
  //     format: "mm-yyyy",
  //     // endDate : '+1m'
  // });

  // // reload_table_resume();
  // });

  // function cari_by_bulan(){
  // // var bulan_table = $('#bulan').val();
  // // alert(bulan_table)
  // reload_table_audit()
  // }

  // function reload_table_audit()
  // {
  // var bulan_table = $('#bulan').val();
  // // var id_machine = $('#id_machine').val();
  // if(bulan_table == '' || id_machine == ''){
  //     swal("PERINGATAN", "Bulan dan Mesin tidak boleh kosong !!!", "warning");
  // }else{
  //     $.ajax({
  //     url : '<?php echo base_url('AuditTrail/AuditTrail_table') ?>',
  //     type: "post",
  //     data: {bulan:bulan_table},
  //     dataType: "JSON",
  //     // beforeSend: function(){
  //     //     $('#t_body').html(spinner);
  //     // },
  //     success : function(data){
  //         // alert(data.respone);
  //         if(data.respone=='sukses'){
  //             $('#bulan_name').html(data.bulan_name);
  //             // $('#div_kanban_tabel').show();
  //             $('#t_body').html(data.tabel);
              
  //         }else{
              
  //         }
  //     },
  //     beforeSend: function(){
  //         $('#spinner').show();
  //         $('#btn_cari').hide();
  //     },complete: function(){
  //         $("#spinner").hide();
  //         $('#btn_cari').show();
  //     },
  // });
  // }


  // }
  // $(document).ready( function () {
  //     $('#table_id').DataTable();
  // } );
</script>