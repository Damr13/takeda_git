    <body>
        <div class="wrapper">
            <div class="page-wrap">
            <h3>
            <b><span class="text-center text-sm-left d-md-inline-block" style="padding:10px 0 10px 30px; font-weight: 900">TAKEDA OEE DASHBOARD</span></b>
            
            </h3>
                <?php
                echo $contents;
                ?>
               
                <div class="ft">
                <footer class="footer">
                    <div class="w-100 clearfix">
                        <span class="text-center text-sm-left d-md-inline-block">Copyright © 2020 Takeda Indonesia v1.0. All Rights Reserved.</span>
                        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center"> Developed  <i class="fa fa-heart text-danger"></i><a href="http://digitaloptima.id/" class="text-dark" target="_blank"> By Digital Optima Integra</a></span>
                    </div>
                </footer>
                </div>
            </div>
        </div>